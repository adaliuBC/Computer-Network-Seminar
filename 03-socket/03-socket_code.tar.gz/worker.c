#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#define  WORKER_NUM 3
#define  BUF_LEN 20
#define  NAME_LEN   17

int main() {
    //create fd
    int wor=0, wors=0, i=0, j=0;
    struct sockaddr_in master, worker;
    int count_msg[26];
    int txtname_len;
    int start[3], end[3];
    int wor_num = 0, book_len = 0, workeread_len[3];
    char ch;
    for(i = 0; i < 26; i++) {
        count_msg[i] = 0;
    }
    for(i = 0; i < WORKER_NUM; i++) {
        start[i] = 0;
        end[i] = 0;
        workeread_len[i] = 0;
    }
    
    
    wor = socket(AF_INET, SOCK_STREAM, 0);
    if (wor == -1) {
        printf("create socket failed\n");
		return -1;
    }
    //bind
    //set master IP as mas.sin_addr.s_addr, bind(master IP????)
    worker.sin_family = AF_INET;
    worker.sin_addr.s_addr = INADDR_ANY;  //mark, ?
    worker.sin_port = htons(12345);
    
    if (bind(wor,(struct sockaddr *)&worker, sizeof(worker)) < 0) {
        perror("bind failed\n");
        return -1;
    }
    printf("bind done\n");
      
        
    //listen
    listen(wor, 128);
    printf("listening...\n");
        //1 time!!!
        // backlog num == 1?????
    
    //accept   //recv an fd
    int slen = sizeof(struct sockaddr_in);
    if ((wors = accept(wor, (struct sockaddr *)&worker, (socklen_t *)&slen)) < 0) {
        perror("accept failed\n");
        return -1;
    }
    printf("connection accepted\n"); 
        
    //recv:message
        //recv 4 times?
        
    recv(wors, &txtname_len, sizeof(int), 0);
    char name[txtname_len];
    for(i = 0; i < txtname_len; i++) {
        name[i] = 0;
    }
    recv(wors, &name, NAME_LEN, 0);
    recv(wors, &wor_num, sizeof(int), 0);
    //recv(wors, &end, sizeof(int), 0);
    //*(int *)((int *)msg + 1)
    printf("recv:%d, %s, %d\n", txtname_len, name, wor_num/*, *((int *)end)*/);
    
    
    //count
    //?????
    FILE *fp;
    if((fp = fopen((char *)name,"r")) == NULL) {
        printf("fail to read\n");
    }
    fseek (fp , 0 , SEEK_END);
    book_len = ftell (fp);
    workeread_len[0] = book_len/3;
    workeread_len[1] = book_len/3;
    workeread_len[2] = book_len - workeread_len[0] - workeread_len[1];
    printf("%d, %d, %d, %d\n", book_len, workeread_len[0], workeread_len[1], workeread_len[2]);
    
    
    for(i = 0; i < WORKER_NUM; i++) {
        for(j = 0; j < i; j++) {
            start[i] += workeread_len[j];
        }
        for(j = 0; j <= i; j++) {
            end[i] += workeread_len[j];
        }
        printf("%d, %d\n", start[i], end[i]);
        //start[i] = htonl(start[i]);
        //end[i] = htonl(end[i]);
        printf("%d, %d\n", start[i], end[i]);
    }
    printf("%d, %d, %d, %d, %d, %d, %d\n", wor_num, start[0], start[1], start[2], end[0], end[1], end[2]);
    
    if(wor_num==256) {  //num2
        fseek (fp, start[1], SEEK_SET);
        for(i = 0; i < end[1]-start[1]; i++) {
            ch = fgetc(fp);
            if(ch >= 'a' && ch <= 'z') {
                count_msg[ch-'a']++;
            } else if(ch >= 'A' && ch <= 'Z') {
                count_msg[ch-'A']++;
            }
        }
    } else if(wor_num==512) {
        fseek (fp, start[2], SEEK_SET);
        for(i = 0; i < end[2]-start[2]; i++) {
            ch = fgetc(fp);
            if(ch >= 'a' && ch <= 'z') {
                count_msg[ch-'a']++;
            } else if(ch >= 'A' && ch <= 'Z') {
                count_msg[ch-'A']++;
            }
        }
    } else {
        fseek (fp, start[0], SEEK_SET);
        for(i = 0; i < end[0]-start[0]; i++) {
            ch = fgetc(fp);
            if(ch >= 'a' && ch <= 'z') {
                count_msg[ch-'a']++;
            } else if(ch >= 'A' && ch <= 'Z') {
                count_msg[ch-'A']++;
            }
        }
    }
    
    
    
    //send:count
    /*for(i = 0; i < 26; i++) {
        count_msg[i] = 20;
    }*/
    send(wors, (void *)count_msg, 26*4, 0);
    printf("sent msg!\n");
}
